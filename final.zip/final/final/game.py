import pygame
import random

from player import Player
from enemy import Enemy

pygame.init()

# Set up the display
display_width = 800
display_height = 600
game_display = pygame.display.set_mode((display_width, display_height))
pygame.display.set_caption('Life Dodger')


clock = pygame.time.Clock()
FPS = 60


player = Player(display_width // 2, display_height // 2)
enemies = [Enemy(random.randint(0, display_width), random.randint(0, display_height)) for i in range(5)]

enemy1 = Enemy(400, 0, 1)
enemy2 = Enemy(0, 300, 2)
enemy3 = Enemy(800, 200, 3)

# Main loop
def game_loop():
    while True:
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()


        player.update()
        for enemy in enemies:
            enemy.update()


        for enemy in enemies:
            if player.rect.colliderect(enemy.rect):
                print('Game Over')
                pygame.quit()
                quit()


        game_display.fill((255, 255, 255))
        player.draw(game_display)
        for enemy in enemies:
            enemy.draw(game_display)
        pygame.display.update()


        clock.tick(FPS)



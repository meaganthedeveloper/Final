from game import game_loop

if __name__ == '__main__':
    game_loop()



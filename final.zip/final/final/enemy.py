import pygame
import os
import random

class Enemy:
    #change enemy type by choosing a number 1-3
    def __init__(self, x, y, enemy_type=1 or 2 or 3):
        self.x = x
        self.y = y
        self.speed = random.randint(1, 5)
        self.width = 50
        self.height = 50
        if enemy_type == 1:
            self.image = pygame.image.load(os.path.join('images', 'enemy.png')).convert_alpha()
        elif enemy_type == 2:
            self.image = pygame.image.load(os.path.join('images', 'enemy2.png')).convert_alpha()
        elif enemy_type == 3:
            self.image = pygame.image.load(os.path.join('images', 'enemy3.png')).convert_alpha()
        self.rect = self.image.get_rect(center=(self.x, self.y))
        self.enemy_type = enemy_type

    def update(self):
        if self.enemy_type == 1:
            self.y += self.speed
            if self.y > 600:
                self.y = 0
                self.x = random.randint(0, 800)
                self.speed = random.randint(1, 5)
        elif self.enemy_type == 2:
            self.x += self.speed
            if self.x < 0 or self.x > 800:
                self.speed *= -1
                self.image = pygame.transform.flip(self.image, True, False)
        elif self.enemy_type == 3:
            self.y += self.speed
            if self.y > 600:
                self.y = 0
                self.x = random.randint(0, 800)
                self.speed = random.randint(1, 5)
                self.image = pygame.transform.rotate(self.image, 90)
        self.rect = self.image.get_rect(center=(self.x, self.y))

    def draw(self, surface):
        surface.blit(self.image, self.rect)


